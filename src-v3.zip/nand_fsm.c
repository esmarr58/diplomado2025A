#include "nand_fsm.h"
#include "nand_driver.h"
#include "config.h"
#include "esp_log.h"
#include "driver/gpio.h"
#include "nand_ftl.h"
#include <string.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

static const char *TAG = "FSM";

static void send_cmd(uint8_t cmd) {
    gpio_set_level(PIN_CLE, 1);
    gpio_set_level(PIN_ALE, 0);
    nand_bus_set_output();
    nand_write_data(cmd);
    nand_pulse_we();
    gpio_set_level(PIN_CLE, 0);
}


static void send_addr(uint8_t addr) {
    gpio_set_level(PIN_CLE, 0);
    gpio_set_level(PIN_ALE, 1);
    nand_bus_set_output();
    nand_write_data(addr);
    nand_pulse_we();
    gpio_set_level(PIN_ALE, 0);
}



static uint8_t read_byte(void) {
    ESP_LOGI(TAG, "Entrando a read_byte...");
    nand_bus_set_input();
    nand_pulse_re();
    uint8_t val = nand_read_data();
    ESP_LOGI(TAG, "Valor leído: 0x%02X", val);
    return val;
}


bool nand_fsm_reset(void) {
    ESP_LOGI(TAG, "Enviando comando RESET (0xFF)");
    send_cmd(0xFF);
    return nand_wait_ready();
}



bool nand_fsm_block_erase(uint32_t  block) {
    ESP_LOGI("FSM", "ERASE BLOCK: bloque=%lu", block);

    uint32_t page_address = block * FTL_PAGES_PER_BLOCK;

        // Ciclo 3: BA[7:6] + PA[5:0]
    uint8_t cycle3 = ((block & 0xC0) >> 6) << 6;         // BA[7:6] << 6 (bits 7:6)
    cycle3 |= (page_address & 0x3F);                     // PA[5:0] (bits 5:0)

    // Ciclo 4: BA[15:8]
    uint8_t cycle4 = (block >> 8) & 0xFF;

    // Ciclo 5: LOW LOW LOW LOW LOW LOW BA[17:16]
    uint8_t cycle5 = (block >> 16) & 0x03;
    gpio_set_level(PIN_CE,0);
    esp_rom_delay_us(2); 

    // 1. Comando 0x60 (Erase Setup)
    gpio_set_level(PIN_CLE, 1);
    gpio_set_level(PIN_ALE, 0);
    nand_write_data(0x60);
    nand_pulse_we();



    // 2. Dirección de fila: ciclos 3, 4, 5
    gpio_set_level(PIN_ALE, 1);
    gpio_set_level(PIN_CLE, 0);
    nand_write_data(cycle3); nand_pulse_we(); // ciclo 3
    nand_write_data(cycle4); nand_pulse_we(); // ciclo 4
    nand_write_data(cycle5); nand_pulse_we(); // ciclo 5

    // 3. Comando 0xD0 (Erase Confirm)
    gpio_set_level(PIN_CLE, 1);
    gpio_set_level(PIN_ALE, 0);
    nand_write_data(0xD0);
    nand_pulse_we();
    gpio_set_level(PIN_CLE, 0);

    // 4. Esperas
    vTaskDelay(pdMS_TO_TICKS(11));

    

    // 5. Leer estado con comando 0x70
    gpio_set_level(PIN_CLE, 1);
    gpio_set_level(PIN_ALE, 0);

    nand_write_data(0x70);
    nand_pulse_we();

    gpio_set_level(PIN_CLE, 0);
    nand_bus_set_input();
    gpio_set_level(PIN_WE,1);
    nand_pulse_re();
    esp_rom_delay_us(10);
    uint8_t status = nand_read_data();
    nand_bus_set_output();

    gpio_set_level(PIN_CE,1);

    for (int i = 0; i < 1000; i++) { // máx ~100 ms si delay = 100 us
        gpio_set_level(PIN_CLE, 1);
        gpio_set_level(PIN_ALE, 0);
        nand_write_data(0x70);
        nand_pulse_we();
        gpio_set_level(PIN_CLE, 0);

        nand_bus_set_input();
        gpio_set_level(PIN_WE,1);
        nand_pulse_re();
        esp_rom_delay_us(10);
        status = nand_read_data();
        nand_bus_set_output();

        if ((status & 0x40) != 0) break; // Bit 6 = 1 → listo
        esp_rom_delay_us(100); // espera activa de 100 us
    }
    

    // 6. Verificar bit 0 del registro de estado (0 = OK, 1 = FAIL)
    if ((status & 0x01) == 0) {
        printf("Bloque %lu borrado exitosamente.\\n", block);
        return true;
    } else {
        printf("Error al borrar el bloque %lu. Estado: 0x%02X\\n", block, status);
        return false;
    }
    

}




uint8_t nand_fsm_read_status(void) {
    send_cmd(0x70);              // Comando READ STATUS
    nand_bus_set_input();        // Configurar el bus para lectura
    nand_pulse_re();             // Pulso de lectura
    uint8_t status = nand_read_data();
    ESP_LOGI("FSM", "Estado leído: 0x%02X", status);
    return status;
}

void nand_send_command(uint8_t command){
    gpio_set_level(PIN_CLE, 1);
    gpio_set_level(PIN_ALE, 0);
    nand_write_data(command);
    nand_pulse_we();
    gpio_set_level(PIN_CLE, 0);
}

void nand_send_address_byte(uint8_t address){
    gpio_set_level(PIN_ALE, 1);   // Activar modo dirección
    gpio_set_level(PIN_CLE, 0);   // Asegurar que no se interprete como comando
    nand_write_data(address);  // Enviar byte de dirección
    nand_pulse_we();             // Pulso de escritura
    gpio_set_level(PIN_ALE, 0);  // Opcional: limpiar ALE
    esp_rom_delay_us(1);

}

void nand_send_data_byte(uint8_t data){
    nand_bus_set_output();       // Asegura que el bus de datos esté en modo salida
    gpio_set_level(PIN_CLE, 0);   // Modo datos
    gpio_set_level(PIN_ALE, 0);   // Modo datos
    gpio_set_level(PIN_WE,1);
    nand_write_data(data);       // Escribir en bus
    nand_pulse_we();
}
uint8_t nand_read_data_byte(){
    gpio_set_level(PIN_CLE, 0);   // Modo datos
    gpio_set_level(PIN_ALE, 0);   // Modo datos
    nand_bus_set_input();        // Configurar bus como entrada
    gpio_set_level(PIN_WE, 1);   // Prepara WE en alto (requisito)
    nand_pulse_re();             // Pulso de lectura RE#
    esp_rom_delay_us(1);         // Delay corto para asegurar estabilidad
    uint8_t data = nand_read_data();
    nand_bus_set_output();       // Restablecer bus como salida
    return data;
}




bool nand_fsm_program_page(const uint8_t *src, uint16_t block, uint16_t page) {
    ESP_LOGI("FSM", "PROGRAM PAGE (80h-10h): bloque=%d, página=%d", block, page);
    uint32_t addr = (block * FTL_PAGES_PER_BLOCK) + page;

    // Ciclo 3: BA[7:6] << 6 | PA[5:0]
    uint8_t addr_cycle3 = ((addr >> 6) & 0xC0) | (addr & 0x3F);

    // Ciclo 4: BA[15:8]
    uint8_t addr_cycle4 = (addr >> 16) & 0xFF;

    // Ciclo 5: LOW LOW LOW LOW LOW LOW BA[17:16]
    uint8_t addr_cycle5 = (addr >> 24) & 0x03;

  
    // 2. Activar chip select
    gpio_set_level(PIN_CE, 0);

    nand_send_command(0x80);
    nand_send_address_byte(0x00);
    nand_send_address_byte(0x00);
    nand_send_address_byte(addr_cycle3);
    nand_send_address_byte(addr_cycle4);
    nand_send_address_byte(addr_cycle5);
    esp_rom_delay_us(1);

    // 6. Ciclos de escritura de datos
    for (int i = 0; i < FTL_PAGE_SIZE; i++) {
        nand_send_data_byte(src[i]);
    }
     nand_send_command(0x10);


    esp_rom_delay_us(2);  
    

     // 5. Leer estado con comando 0x70
    gpio_set_level(PIN_CLE, 1);
    gpio_set_level(PIN_ALE, 0);

    nand_write_data(0x70);
    nand_pulse_we();

    gpio_set_level(PIN_CLE, 0);
    nand_bus_set_input();
    gpio_set_level(PIN_WE,1);
    nand_pulse_re();
    esp_rom_delay_us(10);
    uint8_t status = nand_read_data();
    nand_bus_set_output();


    for (int i = 0; i < 1000; i++) { // máx ~100 ms si delay = 100 us
        gpio_set_level(PIN_CLE, 1);
        gpio_set_level(PIN_ALE, 0);
        nand_write_data(0x70);
        nand_pulse_we();
        gpio_set_level(PIN_CLE, 0);

        nand_bus_set_input();
        gpio_set_level(PIN_WE,1);
        nand_pulse_re();
        esp_rom_delay_us(10);
        status = nand_read_data();
        nand_bus_set_output();

        if ((status & 0x40) != 0) break; // Bit 6 = 1 → listo
        esp_rom_delay_us(100); // espera activa de 100 us
    }
    
        gpio_set_level(PIN_CE,1);

    // 6. Verificar bit 0 del registro de estado (0 = OK, 1 = FAIL)
    if ((status & 0x01) == 0) {
        printf("Pagia %d escrito exitosamente.\\n", block);
        return true;
    } else {
        printf("Error al escribir el la pagina %d. Estado: 0x%02X\\n", block, status);
        return false;
    }
    
   
}



bool nand_fsm_read_page(uint8_t *dest, uint16_t block, uint16_t page) {
    ESP_LOGI("FSM", "READ PAGE: bloque=%d, página=%d", block, page);

    // 1. Asegurar que el chip está seleccionado
    gpio_set_level(PIN_CE, 0);

    // 2. Enviar comando 0x00 (inicio de lectura)
    gpio_set_level(PIN_CLE, 1);
    gpio_set_level(PIN_ALE, 0);
    nand_bus_set_output();
    nand_write_data(0x00);
    nand_pulse_we();
    gpio_set_level(PIN_CLE, 0);

    // 3. Enviar las 5 direcciones (2 de columna, 3 de página)
    gpio_set_level(PIN_ALE, 1);
    nand_write_data(0x00); nand_pulse_we();  // Columna LSB
    nand_write_data(0x00); nand_pulse_we();  // Columna MSB

    uint32_t row = (block * FTL_PAGES_PER_BLOCK) + page;
    nand_write_data((row >>  0) & 0xFF); nand_pulse_we();
    nand_write_data((row >>  8) & 0xFF); nand_pulse_we();
    nand_write_data((row >> 16) & 0xFF); nand_pulse_we();
    gpio_set_level(PIN_ALE, 0);

    // 4. Enviar comando 0x30 (ejecutar lectura)
    gpio_set_level(PIN_CLE, 1);
    nand_write_data(0x30);
    nand_pulse_we();
    gpio_set_level(PIN_CLE, 0);

    // 5. Esperar a que la memoria esté lista (monitorear R/B#)
    if (!nand_wait_ready()) {
        ESP_LOGE("FSM", "Timeout esperando a que NAND esté lista después de 0x30");
        gpio_set_level(PIN_CE, 1);
        return false;
    }

    // 6. (Opcional si se usó 0x70): READ MODE 0x00 para asegurar salida de datos
    // gpio_set_level(PIN_CLE, 1);
    // nand_write_data(0x00);
    // nand_pulse_we();
    // gpio_set_level(PIN_CLE, 0);

    // 7. Configurar bus como entrada
    nand_bus_set_input();

    // 8. Leer datos de la página
    for (int i = 0; i < FTL_PAGE_TOTAL_SIZE; i++) {
        nand_pulse_re();
        dest[i] = nand_read_data();
    }

    // 9. Desactivar el chip select
    gpio_set_level(PIN_CE, 1);
    return true;
}



bool nand_fsm_read_id(uint8_t *buffer, uint8_t length) {
    ESP_LOGI("FSM", "Reseteando NAND...");

    // Activar el chip
    gpio_set_level(PIN_CE, 0);

    // Enviar comando RESET (0xFF)
    gpio_set_level(PIN_CLE, 1);
    gpio_set_level(PIN_ALE, 0);
    nand_bus_set_output();
    nand_write_data(0xFF);
    nand_pulse_we();
    gpio_set_level(PIN_CLE, 0);
    esp_rom_delay_us(10);

    // Esperar a que !RB esté en alto (listo)
    int timeout = 1000;
    while (gpio_get_level(PIN_RB) == 0 && timeout--) {
        esp_rom_delay_us(1);
    }
    if (timeout <= 0) {
        ESP_LOGE("FSM", "Timeout tras RESET: ¡La NAND no respondió!");
        gpio_set_level(PIN_CE, 1);
        return false;
    }

    ESP_LOGI("FSM", "Enviando comando READ ID (0x90)");

    // Enviar comando READ ID (0x90)
    gpio_set_level(PIN_CLE, 1);
    gpio_set_level(PIN_ALE, 0);
    nand_bus_set_output();
    nand_write_data(0x90);
    nand_pulse_we();
    gpio_set_level(PIN_CLE, 0);

    // Enviar dirección de columna 0x00
    gpio_set_level(PIN_ALE, 1);
    nand_write_data(0x00);
    nand_pulse_we();
    gpio_set_level(PIN_ALE, 0);

    // Cambiar a modo lectura
    nand_bus_set_input();

    // Leer los bytes de ID
    for (uint8_t i = 0; i < length; i++) {
        nand_pulse_re();
        buffer[i] = nand_read_data();
        ESP_LOGI("FSM", "Byte ID[%d] = 0x%02X", i, buffer[i]);
    }

    // Validar si parece válida
    if (buffer[0] == 0xFF || buffer[0] == 0x00) {
        ESP_LOGW("FSM", "ID inválido o memoria no conectada");
        gpio_set_level(PIN_CE, 1);
        return false;
    }

    // Desactivar chip select
    gpio_set_level(PIN_CE, 1);
    gpio_set_level(PIN_WE, 1);
    gpio_set_level(PIN_RE, 1);

    return true;
}

bool nand_fsm_read_onfi_param_page(uint8_t *buffer, size_t length) {
    ESP_LOGI("FSM", "READ PARAMETER PAGE (ECh)");

    if (length < 256) {
        ESP_LOGE("FSM", "Buffer demasiado pequeño: mínimo 256 bytes requeridos");
        return false;
    }

    // 1. Activar CE#
    gpio_set_level(PIN_CE, 0);

    // 2. Enviar comando ECh (READ PARAMETER PAGE)
    gpio_set_level(PIN_CLE, 1);
    gpio_set_level(PIN_ALE, 0);
    nand_bus_set_output();
    nand_write_data(0xEC);  // ECh
    nand_pulse_we();
    gpio_set_level(PIN_CLE, 0);

    // 3. Enviar dirección 00h
    gpio_set_level(PIN_ALE, 1);
    nand_write_data(0x00);
    nand_pulse_we();
    gpio_set_level(PIN_ALE, 0);

    // 4. Esperar a que esté listo (!RB == HIGH)
    if (!nand_wait_ready()) {
        ESP_LOGE("FSM", "Timeout esperando ready tras comando ECh");
        gpio_set_level(PIN_CE, 1);
        return false;
    }

    // 5. Leer los 256 bytes del parámetro ONFI
    nand_bus_set_input();
    for (int i = 0; i < 256; i++) {
        nand_pulse_re();
        buffer[i] = nand_read_data();
    }

    // 6. Desactivar CE#
    gpio_set_level(PIN_CE, 1);

    return true;
}

bool nand_unlock_all_blocks(void) {
    ESP_LOGI("FSM", "Desbloqueando todos los bloques...");

    // 1. Comando UNLOCK LOW (23h) - límite inferior
    gpio_set_level(PIN_CE, 0);
    nand_bus_set_output();
    send_cmd(0x23);
    
    // Dirección inferior: bloque 0 (3 ciclos)
    gpio_set_level(PIN_ALE, 1);
    nand_write_data(0x00); nand_pulse_we();  // BA7-BA0
    nand_write_data(0x00); nand_pulse_we();  // BA15-BA8
    nand_write_data(0x00); nand_pulse_we();  // BA17-BA16
    gpio_set_level(PIN_ALE, 0);

    // 2. Comando UNLOCK HIGH (24h) - límite superior
    send_cmd(0x24);
    
    // Dirección superior: bloque máximo (4095 para 8Gb)
    gpio_set_level(PIN_ALE, 1);
    nand_write_data(0xFF); nand_pulse_we();  // BA7-BA0 (0xFF = bloque 4095)
    nand_write_data(0x0F); nand_pulse_we();  // BA15-BA8 (0x0F porque 4095 >> 8 = 0x0F)
    nand_write_data(0x00); nand_pulse_we();  // BA17-BA16
    gpio_set_level(PIN_ALE, 0);

    // 3. Comando LOCK (2Ah) para confirmar
    send_cmd(0x2A);
    gpio_set_level(PIN_CE, 1);
    esp_rom_delay_us(2);

    // 4. Verificar estado
    gpio_set_level(PIN_CE, 0);
    send_cmd(0x7A);  // BLOCK LOCK READ STATUS
    nand_bus_set_input();
    nand_pulse_re();
    uint8_t status = nand_read_data();
    gpio_set_level(PIN_CE, 1);

    // Verificar bits de estado (Tabla 20, pág. 82)
    if ((status & 0x01) || !(status & 0x80)) {
        ESP_LOGE("FSM", "Fallo en desbloqueo. Estado: 0x%02X", status);
        return false;
    }

    ESP_LOGI("FSM", "Todos los bloques desbloqueados exitosamente.");
    return true;
}

uint8_t nand_fsm_read_block_lock_status(uint16_t block) {
    ESP_LOGI("FSM", "Leyendo estado de bloqueo del bloque %u", block);

    // 1. Calcular dirección de fila (página 0 del bloque)
    uint32_t row_addr = block * FTL_PAGES_PER_BLOCK;

    // 2. Activar chip select
    gpio_set_level(PIN_CE, 0);

    // 3. Enviar comando 0x7A (BLOCK LOCK READ STATUS)
    gpio_set_level(PIN_CLE, 1);
    gpio_set_level(PIN_ALE, 0);
    nand_bus_set_output();
    nand_write_data(0x7A);
    nand_pulse_we();
    gpio_set_level(PIN_CLE, 0);

    // 4. Enviar ciclos de dirección (3 ciclos de fila, invert_area_bit = 0)
    gpio_set_level(PIN_ALE, 1);
    nand_write_data((row_addr >> 0) & 0xFF); nand_pulse_we();  // A0-A7
    nand_write_data((row_addr >> 8) & 0xFF); nand_pulse_we();  // A8-A15
    nand_write_data((row_addr >> 16) & 0xFF); nand_pulse_we(); // A16-A23
    gpio_set_level(PIN_ALE, 0);

    // 5. Esperar tRR (mínimo 25 ns, usamos 1 us por seguridad)
    esp_rom_delay_us(1);

    // 6. Leer resultado desde I/O (señalado por la caída de RE#)
    nand_bus_set_input();
    nand_pulse_re();
    uint8_t lock_status = nand_read_data();

    // 7. Desactivar chip select
    gpio_set_level(PIN_CE, 1);

    ESP_LOGI("FSM", "Estado de bloqueo del bloque %u: 0x%02X", block, lock_status);
    return lock_status;
}