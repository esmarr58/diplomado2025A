#include <stdio.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/uart.h"
#include "esp_log.h"
#include "nand_driver.h"
#include "nand_fsm.h"
#include "nand_ftl.h"
#include "config.h"


#define UART_NUM UART_NUM_0
#define BUF_SIZE 1024

static const char *TAG = "MAIN";

static uint8_t valor_incremental = 0;
static uint16_t current_block = 0;
static uint8_t current_page = 0;
static uint16_t last_written_block = 0;
static uint16_t last_written_page = 0;


// Tarea en CPU0: escanea serial y ejecuta lectura de ID
void task_cpu0(void *pvParameters) {
    uint8_t data[BUF_SIZE];
    uint8_t id[8];

    ESP_LOGI(TAG, "Inicializando NAND...");
    nand_gpio_init();
    nand_unlock_all_blocks();
    vTaskDelay(pdMS_TO_TICKS(100));

    ESP_LOGI(TAG, "Esperando comando por UART...");

    while (1) {
        int len = uart_read_bytes(UART_NUM, data, BUF_SIZE, pdMS_TO_TICKS(100));
        if (len > 0) {
            ESP_LOGI(TAG, "Comando recibido: '%c'", data[0]);
            if (data[0] == 'a') {
                ESP_LOGI(TAG, "Comando 'a' detectado → lectura de ID NAND...");

                if (nand_fsm_read_id(id, sizeof(id))) {
                    ESP_LOGI(TAG, "ID de la NAND:");
                    for (int i = 0; i < 8; i++) {
                        printf("0x%02X ", id[i]);
                    }
                    printf("\n");
                } else {
                    ESP_LOGE(TAG, "Fallo al leer ID. ¿Memoria no conectada?");
                }
            }
            if (data[0]  == 'b') {
                ESP_LOGI("MAIN", "Comando 'b' detectado → lectura de STATUS...");
                uint8_t status = nand_fsm_read_status();

                // Puedes interpretar el bit 6 (Ready/Busy)
                if (status & 0x40)
                    ESP_LOGI("MAIN", "✅ NAND está lista");
                else
                    ESP_LOGW("MAIN", "⏳ NAND ocupada");

                // Puedes interpretar el bit 0 (Pass/Fail)
                if (status & 0x01)
                    ESP_LOGE("MAIN", "❌ Falló la última operación");
                else
                    ESP_LOGI("MAIN", "✅ Última operación exitosa");
            }
           else if (data[0] == 'c') {
                printf("Comando 'c' detectado → lectura de página %d del bloque %d...\n", 
                    last_written_page, last_written_block);

                uint32_t row_addr = (last_written_block * FTL_PAGES_PER_BLOCK) + last_written_page;
                printf("→ Dirección absoluta (row address): 0x%05lX\n", (unsigned long)row_addr);


                    static uint8_t buffer[FTL_PAGE_TOTAL_SIZE] = {0};
                printf("Contenido del buffer:\n");
                for (int i = 0; i < 64; i++) {
                    printf("0x%02X ", buffer[i]);
                    if ((i + 1) % 16 == 0) printf("\n");  // salto de línea cada 16 bytes
                }

                if (nand_fsm_read_page(buffer, last_written_block, last_written_page)) {
                    printf("Lectura exitosa. Contenido de los 4096 bytes:\n");
                    for (int i = 0; i < FTL_PAGE_SIZE; i++) {
                        printf("0x%02X ", buffer[i]);
                        if ((i + 1) % 16 == 0) printf("\n");
                    }
                } else {
                    printf("❌ Error en la lectura\n");
                }
            }

            else if (data[0] == 'd') {
            printf("Comando 'D' → guardar valor %d en bloque=%d página=%d\n", 
                    valor_incremental, current_block, current_page);

            uint32_t row_addr = (current_block * FTL_PAGES_PER_BLOCK) + current_page;
            printf("→ Dirección absoluta (row address): 0x%05lX\n", (unsigned long)row_addr);

            

            static uint8_t buffer[FTL_PAGE_SIZE];
            for (int i = 0; i < FTL_PAGE_SIZE; i++) {
                buffer[i] = i % 256;
            }

            printf("Buffer a escribir (primeros 32 bytes):\n");
            for (int i = 0; i < 32; i++) {
                printf("0x%02X ", buffer[i]);
                if ((i + 1) % 8 == 0) printf("\n");
            }

            if (nand_fsm_program_page(buffer, current_block, current_page)) {
                printf("✓ Valor %d guardado exitosamente\n", valor_incremental);
                last_written_block = current_block;
                last_written_page = current_page;

                valor_incremental++;
                current_page++;
                if (current_page >= FTL_PAGES_PER_BLOCK) {
                    current_page = 0;
                    current_block++;
                    if (current_block >= FTL_TOTAL_BLOCKS) {
                        current_block = 0;
                        valor_incremental = 0;
                        printf("⚠️ Se reinició el recorrido de bloques\n");
                    }
                }
            } else {
                printf("❌ Error al guardar página\n");
            }
        }
        else if (data[0] == 'e') {
            ESP_LOGI(TAG, "Comando 'e' → lectura de ONFI Parameter Page...");

            static uint8_t param_page[256] = {0};

            if (nand_fsm_read_onfi_param_page(param_page, sizeof(param_page))) {
                printf("Lectura exitosa de la página de parámetros ONFI:\n");
                for (int i = 0; i < 256; i++) {
                    printf("0x%02X ", param_page[i]);
                    if ((i + 1) % 16 == 0) printf("\n");
                }
            } else {
                ESP_LOGE(TAG, "❌ Falló la lectura de la página de parámetros");
            }
        }
        else if (data[0] == 'f') {
            ESP_LOGI("MAIN", "Comando 'F' → borrar bloque 0");
            if (nand_fsm_block_erase(0)) {
                ESP_LOGI("MAIN", "Bloque 0 borrado exitosamente");
            } else {
                ESP_LOGE("MAIN", "Fallo al borrar el bloque 0");
            }
        }
        else if(data[0] == 'g') {
    ESP_LOGI("MAIN", "Comando 'G' → leer estado de bloqueo del bloque 0");

    uint8_t status = nand_fsm_read_block_lock_status(0);

    // Interpretar bits del status
    if (status & 0x80) {
        ESP_LOGE("MAIN", "Error en la lectura del estado de bloqueo");
    } else {
        if (status & 0x02) {
            ESP_LOGW("MAIN", "Bloque 0 está bloqueado FUERTEMENTE (locked tight)");
        } else if (status & 0x01) {
            ESP_LOGW("MAIN", "Bloque 0 está bloqueado (locked)");
        } else {
            ESP_LOGI("MAIN", "Bloque 0 está desbloqueado");
        }
    }
}

        else if (data[0] == 'z') {
    uint16_t blk = 4095;
    uint16_t pg = 62;
    uint32_t addr = blk * FTL_PAGES_PER_BLOCK + pg;

    printf("Comando 'z' → lectura de página virgen\n");
    printf("→ Dirección absoluta (row address): 0x%05lX\n", addr);
    printf("→ Bloque: %d, Página: %d\n", blk, pg);

    static uint8_t buffer[FTL_PAGE_TOTAL_SIZE] = {0};
    printf("Contenido del buffer:\n");
    for (int i = 0; i < 64; i++) {
        printf("0x%02X ", buffer[i]);
        if ((i + 1) % 16 == 0) printf("\n");  // salto de línea cada 16 bytes
    }


    // RESET antes de leer
    if (!nand_fsm_reset()) {
        printf("❌ Fallo al hacer RESET antes de leer\n");
        return;
    }

    if (nand_fsm_read_page(buffer, blk, pg)) {
        printf("Lectura exitosa. Primeros 64 bytes:\n");
        for (int i = 0; i < 64; i++) {
            printf("0x%02X ", buffer[i]);
            if ((i + 1) % 16 == 0) printf("\n");
        }

        bool virgen = true;
        for (int i = 0; i < FTL_PAGE_TOTAL_SIZE; i++) {
            if (buffer[i] != 0xFF) {
                virgen = false;
                break;
            }
        }

        if (virgen)
            printf("✅ Página virgen (todos los bytes = 0xFF)\n");
        else
            printf("⚠️ Página ya fue escrita (al menos un byte ≠ 0xFF)\n");
    } else {
        printf("❌ Error al leer la página\n");
    }
}

    }

    }
}

// Tarea en CPU1: espera e imprime estado
void task_cpu1(void *pvParameters) {
    while (1) {
        ESP_LOGI(TAG, "CPU1 en espera...");
        vTaskDelay(pdMS_TO_TICKS(3000));
    }
}

void app_main(void) {
    ESP_LOGI(TAG, "Configurando UART...");
    const uart_config_t uart_config = {
        .baud_rate = 115200,
        .data_bits = UART_DATA_8_BITS,
        .parity    = UART_PARITY_DISABLE,
        .stop_bits = UART_STOP_BITS_1,
        .flow_ctrl = UART_HW_FLOWCTRL_DISABLE
    };
    uart_driver_install(UART_NUM, BUF_SIZE * 2, 0, 0, NULL, 0);
    uart_param_config(UART_NUM, &uart_config);
    uart_set_pin(UART_NUM, UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE,
                 UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE);

    // Oculta los logs excesivos del driver GPIO
    esp_log_level_set("gpio", ESP_LOG_WARN);

    // Crear tareas
    xTaskCreatePinnedToCore(task_cpu0, "task_cpu0", 12288, NULL, 5, NULL, 0);
    xTaskCreatePinnedToCore(task_cpu1, "task_cpu1", 12288, NULL, 3, NULL, 1);
}
