#ifndef NAND_FSM_H
#define NAND_FSM_H

#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>


bool nand_fsm_reset(void);
bool nand_fsm_read_id(uint8_t *buffer, uint8_t length);
uint8_t nand_fsm_read_status(void);
bool nand_fsm_program_page(const uint8_t *src, uint16_t block, uint16_t page);
bool nand_fsm_block_erase(uint16_t block);
bool nand_fsm_read_onfi_param_page(uint8_t *buffer, size_t length);
bool nand_fsm_read_page(uint8_t *dest, uint16_t block, uint16_t page);
bool nand_unlock_all_blocks(void);
uint8_t nand_fsm_read_block_lock_status(uint16_t block);
#endif // NAND_FSM_H
